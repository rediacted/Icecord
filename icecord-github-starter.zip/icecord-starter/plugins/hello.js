// Example Icecord plugin. It is registered by the Icecord web loader.
window.Icecord.PluginHost.register({
  name: 'Welcome Toast',
  description: 'Shows a small welcome notification when enabled.',
  start(api) {
    api.toast('Welcome to Icecord!');
  },
  stop(api) {
    api.toast('Welcome Toast disabled.');
  }
});
