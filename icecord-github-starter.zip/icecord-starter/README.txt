ICECORD GITHUB STARTER

Upload the plugins/, themes/, and assets/ folders to the ROOT of a PUBLIC GitHub repository.

Example repository layout:
  plugins/hello.js
  themes/blue-glow.css
  assets/  (optional image/font files)

Then edit CONFIG at the top of icecord-web-loader.js:
  owner: 'YOUR_GITHUB_USERNAME'
  repo: 'icecord'
  branch: 'main'

Plugin format:
  window.Icecord.PluginHost.register({
    name: 'My Plugin',
    description: 'What it does',
    start(api) { /* called when enabled */ },
    stop(api) { /* called when disabled */ }
  });

Available plugin API:
  api.toast(message)
  api.settings  // copy of current settings
  api.addStyle(id, css) // inject/update a style; returns a cleanup function
  api.getAsset(filename) // returns a data URL or null
  api.openExternal(url) // opens HTTP(S) links only

IMPORTANT:
Only load plugins from a repository you own or have reviewed. Browser plugins execute with the privileges of the page and can potentially read or change anything available to page JavaScript. This starter intentionally provides no Yapin login tokens or message API.
